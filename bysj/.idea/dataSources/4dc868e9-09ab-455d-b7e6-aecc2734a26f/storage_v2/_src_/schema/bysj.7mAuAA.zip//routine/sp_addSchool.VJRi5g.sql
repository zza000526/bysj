create
    definer = root@localhost procedure sp_addSchool(IN description varchar(255), IN no varchar(255),
                                                    IN remarks varchar(255), OUT id int)
BEGIN
    INSERT INTO school(description,no,remarks)
    VALUES(description,no,remarks);
    SELECT LAST_INSeRT_ID() id;
END;

